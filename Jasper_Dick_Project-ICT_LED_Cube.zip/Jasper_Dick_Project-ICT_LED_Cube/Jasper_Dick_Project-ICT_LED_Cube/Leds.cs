﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;

namespace Jasper_Dick_Project_ICT_LED_Cube
{
    class Leds
    {

        public void Tevoorschijn(byte[] test, SerialPort serielport)
        {
            test = new byte[81];
            test[0] = 255;
            test[8] = 255;
            test[19] = 255;
            test[24] = 255;
            test[41] = 255;
            test[40] = 255;
            test[39] = 255;
            test[54] = 255;
            test[61] = 255;
            test[74] = 255;
            test[78] = 255;

            serielport.Write(test, 0, 81);
        }
        public void kwartslag1(byte[] test, SerialPort serielport) 
        {
            test = new byte[81];
            test[0] = 255;
            test[6] = 255;
            test[20] = 255;
            test[25] = 255;
            test[41] = 255;
            test[40] = 255;
            test[39] = 255;
            test[55] = 255;
            test[62] = 255;
            test[72] = 255;
            test[78] = 255;

            serielport.Write(test, 0, 81);
        }
        public void kwartslag2(byte[] test, SerialPort serielport) 
        {
            test = new byte[81];
            test[1] = 255;
            test[6] = 255;
            test[18] = 255;
            test[26] = 255;
            test[41] = 255;
            test[40] = 255;
            test[39] = 255;
            test[56] = 255;
            test[60] = 255;
            test[72] = 255;
            test[79] = 255;

            serielport.Write(test, 0, 81);
        }
        public void kwartslag3(byte[] test, SerialPort serielport) 
        {
            test = new byte[81];
            test[2] = 255;
            test[7] = 255;
            test[18] = 255;
            test[24] = 255;
            test[41] = 255;
            test[40] = 255;
            test[39] = 255;
            test[54] = 255;
            test[60] = 255;
            test[73] = 255;
            test[80] = 255;

            serielport.Write(test, 0, 81);
        }
        public void LEDSuit(byte[] test, SerialPort serielport)
        {
            test = new byte[81];
            test[2] = 0;
            test[7] = 0;
            test[18] = 0;
            test[24] = 0;
            test[41] = 0;
            test[40] = 0;
            test[39] = 0;
            test[54] = 0;
            test[60] = 0;
            test[73] = 0;
            test[80] = 0;

            serielport.Write(test, 0, 81);
        }
    }
}
