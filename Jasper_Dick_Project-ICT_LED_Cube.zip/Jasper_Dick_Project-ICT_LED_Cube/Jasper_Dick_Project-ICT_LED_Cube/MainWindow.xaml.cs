﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO.Ports;
using Jasper_Dick_Project_ICT_LED_Cube;

namespace Jasper_Dick_Project_ICT_LED_Cube
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SerialPort mijnPoort;
        Leds led;
        byte[] data = new byte[81];

        public MainWindow()
        {
            InitializeComponent();

            led = new Leds();

            mijnPoort = new SerialPort();
            mijnPoort.BaudRate = 250000;
            mijnPoort.StopBits = StopBits.One;
            mijnPoort.DataBits = 8;
            mijnPoort.Parity = Parity.None;

            cbxComPorts.Items.Add("None");
            foreach (string s in SerialPort.GetPortNames())
                cbxComPorts.Items.Add(s);
        }

        private void cbxComPorts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (mijnPoort != null)
            {
                if (mijnPoort.IsOpen)
                    mijnPoort.Close();

                if(cbxComPorts.SelectedItem.ToString() != "None")
                {
                    mijnPoort.PortName = cbxComPorts.SelectedItem.ToString();
                    mijnPoort.Open();
                }
            }
        }
        private void BtnX1_Click(object sender, RoutedEventArgs e)
        {
            led.Tevoorschijn(data, mijnPoort);    
        }
        private void BtnX2_Click(object sender, RoutedEventArgs e)
        {
            led.kwartslag1(data, mijnPoort);         
        }

        private void BtnX3_Click(object sender, RoutedEventArgs e)
        {
            led.kwartslag2(data, mijnPoort);           
        }

        private void BtnX4_Click(object sender, RoutedEventArgs e)
        {
            led.kwartslag3(data, mijnPoort);       
        }

        private void sldrInput_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double x = Convert.ToDouble(sldrInput.Value);

            if (x == 1)
            {
                led.Tevoorschijn(data, mijnPoort);
            }  
            
            if (x == 2)
            {
                led.kwartslag1(data, mijnPoort);
            }

            if (x == 3)
            {
                led.kwartslag2(data, mijnPoort);
            }

            if (x == 4)
            {
                led.kwartslag3(data, mijnPoort);
            }

            if (x == 5)
            {
                led.LEDSuit(data, mijnPoort);
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (mijnPoort != null && mijnPoort.IsOpen)
            {
                LedUit(data, mijnPoort);
              
            }
        }
        private void LedUit(byte[] data,SerialPort COMpoort)
        {
            data = new byte[81];
            data[0] = 0;
            COMpoort.Write(data, 0, 81);
        }
    }
}
